from .knn import KNN
from .svm import SVM
from .nn import NeuralNetwork
from .nb import NaiveBayes
